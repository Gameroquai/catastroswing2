import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;

public class Conversor extends JFrame {

    public static void main(String[] args) {
        Conversor conversor = new Conversor();
        conversor.setVisible(true);

    }

    public Conversor() throws HeadlessException {
        setSize(504,319);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        Container contentPane = getContentPane();
        GridBagConstraints gridBagConstraints = new GridBagConstraints();
        JPanel jPanel = new JPanel(new GridBagLayout());
        contentPane.add(jPanel, BorderLayout.CENTER);

       // gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = GridBagConstraints.FIRST_LINE_START;
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        JLabel jLabel = new JLabel("ENTRADA");
        jPanel.add(jLabel,gridBagConstraints);
        gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        JLabel jLabel1 = new JLabel("Paso a ...");
        jPanel.add(jLabel1,gridBagConstraints);
        gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        JTextField jTextField = new JTextField(8);
        jPanel.add(jTextField,gridBagConstraints);
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        JButton jButton = new JButton("Convertir");
        jPanel.add(jButton,gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        JTextField jTextField1 = new JTextField("Resultado");
        jPanel.add(jTextField1,gridBagConstraints);







    }

    /**
     *
     * @param numDecimal
     * @return numero convertido a binario, si el numero es negativo, devuelve -1
     *
     */

     static int decimalBinario(int numDecimal){
         ArrayList resultado = new ArrayList();
         String resul = "";
         while (numDecimal>0){

             int resto = numDecimal % 2;
             resultado.add(resto);
             numDecimal = numDecimal / 2;

         }
         if(numDecimal<0) return -1;
         Collections.reverse(resultado);

         for (Object res:resultado) {
             resul += res.toString();
             
         }

         return Integer.parseInt(resul);
    }

     static int binarioDecimal(int number) {
        int decimal = 0;
        int potencia = 0;
         String s = String.valueOf(number);

         if (number > 0 && s.matches("\\b[01]+\\b")) {
             while (number != 0) {
                 int lastDigit = number % 10;
                 decimal += lastDigit * Math.pow(2, potencia);
                 potencia++;
                 number = number / 10;

             }

         }else return -1;

        return decimal;
    }
}
